import { useGLTF } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useKeyboard } from "@/game/useKeyboard";
import { createVehicle, updateVehicle } from "@/game/vehicle";
import { buildCoins, CELL, resolveCity, WORLD_LIMIT } from "@/game/world";
import { gameStats } from "@/game/stats";

useGLTF.preload("/models/cars/sedan-sports.glb");

const idealOffset = new THREE.Vector3(0, 5.2, -11);
const idealLookAt = new THREE.Vector3(0, 1.6, 8);
const _offset = new THREE.Vector3();
const _lookAt = new THREE.Vector3();
const _lookTarget = new THREE.Vector3();

export function PlayerCar({
  touch,
}: {
  touch: React.RefObject<{ forward: number; steer: number; brake: boolean }>;
}) {
  const { scene } = useGLTF("/models/cars/sedan-sports.glb");
  const car = useMemo(() => {
    const c = scene.clone(true);
    c.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        o.castShadow = true;
        o.receiveShadow = true;
      }
    });
    return c;
  }, [scene]);

  const root = useRef<THREE.Group>(null);
  const lean = useRef<THREE.Group>(null);
  const coinGroup = useRef<THREE.Group>(null);
  const keys = useKeyboard();
  const state = useRef(createVehicle(CELL / 2, CELL / 2));
  const coins = useMemo(() => buildCoins(), []);
  const taken = useRef<boolean[]>(coins.map(() => false));
  gameStats.total = coins.length;

  useFrame(({ camera }, rawDelta) => {
    const dt = Math.min(rawDelta, 0.05);
    const k = keys.current;
    const t = touch.current;
    const s = state.current;

    const forward =
      (k.has("KeyW") || k.has("ArrowUp") ? 1 : 0) -
      (k.has("KeyS") || k.has("ArrowDown") ? 1 : 0) +
      (t?.forward ?? 0);
    const steer =
      (k.has("KeyA") || k.has("ArrowLeft") ? 1 : 0) -
      (k.has("KeyD") || k.has("ArrowRight") ? 1 : 0) -
      (t?.steer ?? 0);

    updateVehicle(
      s,
      {
        forward: Math.max(-1, Math.min(1, forward)),
        steer: Math.max(-1, Math.min(1, steer)),
        brake: k.has("Space") || !!t?.brake,
      },
      dt,
    );

    // keep the car on the streets
    const fixed = resolveCity(s.px, s.pz, 1.5);
    if (fixed.hit) {
      if (fixed.x !== s.px) s.vx *= -0.2;
      if (fixed.z !== s.pz) s.vz *= -0.2;
      s.px = fixed.x;
      s.pz = fixed.z;
    }
    const edge = WORLD_LIMIT - 1.5;
    s.px = Math.max(-edge, Math.min(edge, s.px));
    s.pz = Math.max(-edge, Math.min(edge, s.pz));

    if (root.current) {
      root.current.position.set(s.px, 0, s.pz);
      root.current.rotation.y = s.yaw;
    }
    if (lean.current) {
      const targetRoll = -s.slip * 0.18;
      lean.current.rotation.z +=
        (targetRoll - lean.current.rotation.z) * 6 * dt;
    }

    // chase camera
    const lerp = 1 - Math.exp(-4 * dt);
    _offset.copy(idealOffset).applyQuaternion(root.current!.quaternion);
    _offset.add(root.current!.position);
    camera.position.lerp(_offset, lerp);
    _lookAt.copy(idealLookAt).applyQuaternion(root.current!.quaternion);
    _lookAt.add(root.current!.position);
    _lookTarget.lerp(_lookAt, lerp);
    camera.lookAt(_lookTarget);

    const cam = camera as THREE.PerspectiveCamera;
    const targetFov = 58 + Math.min(s.speed, 40) * 0.35;
    cam.fov += (targetFov - cam.fov) * 3 * dt;
    cam.updateProjectionMatrix();

    // coins
    if (coinGroup.current) {
      coinGroup.current.children.forEach((c, i) => {
        if (taken.current[i]) return;
        c.rotation.y += dt * 2.2;
        c.position.y = 1.1 + Math.sin(performance.now() * 0.003 + i) * 0.15;
        const dx = c.position.x - s.px;
        const dz = c.position.z - s.pz;
        if (dx * dx + dz * dz < 9) {
          taken.current[i] = true;
          c.visible = false;
          gameStats.coins += 1;
        }
      });
    }

    const drifting = Math.abs(s.slip) > 0.28 && s.speed > 6;
    if (drifting) gameStats.driftScore += s.speed * dt * 2;
    gameStats.drifting = drifting;
    gameStats.speed = s.speed * 3.2;
  });

  return (
    <>
      <group ref={root}>
        <group ref={lean}>
          <primitive object={car} scale={1.7} rotation={[0, Math.PI, 0]} />
        </group>
      </group>

      <group ref={coinGroup}>
        {coins.map((c, i) => (
          <mesh key={i} position={[c.x, 1.1, c.z]} castShadow>
            <torusGeometry args={[0.7, 0.22, 8, 18]} />
            <meshStandardMaterial
              color="#ffcf3d"
              emissive="#ffae00"
              emissiveIntensity={0.5}
              roughness={0.35}
              metalness={0.4}
            />
          </mesh>
        ))}
      </group>
    </>
  );
}
