import { Environment, Lightformer } from "@react-three/drei";
import { Canvas } from "@react-three/fiber";
import { Suspense, useRef } from "react";
import { City } from "./City";
import { HUD } from "./HUD";
import { ParkedCars } from "./ParkedCars";
import { PlayerCar } from "./PlayerCar";

export function GameCanvas() {
  const touch = useRef({ forward: 0, steer: 0, brake: false });

  return (
    <div className="fixed inset-0 bg-sky">
      <Canvas
        shadows
        dpr={[1, 2]}
        camera={{ position: [0, 6, -12], fov: 58 }}
        gl={{ antialias: true }}
      >
        <color attach="background" args={["#a9dcf5"]} />
        <fog attach="fog" args={["#bfe4f7", 90, 240]} />

        <hemisphereLight args={["#cfe9ff", "#7f9a6a", 0.75]} />
        <directionalLight
          position={[60, 80, 40]}
          intensity={2.2}
          color="#fff3d6"
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
          shadow-camera-left={-70}
          shadow-camera-right={70}
          shadow-camera-top={70}
          shadow-camera-bottom={-70}
          shadow-camera-far={220}
        />

        <Environment>
          <Lightformer
            intensity={2}
            position={[0, 10, 0]}
            scale={[20, 20, 1]}
            color="#ffffff"
          />
          <Lightformer
            intensity={1}
            color="#bcd9ff"
            position={[-10, 2, -2]}
            rotation-y={Math.PI / 2}
            scale={[30, 2, 1]}
          />
        </Environment>

        <Suspense fallback={null}>
          <City />
          <ParkedCars />
          <PlayerCar touch={touch} />
        </Suspense>
      </Canvas>

      <HUD touch={touch} />
    </div>
  );
}
