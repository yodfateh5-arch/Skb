import { useEffect, useState } from "react";
import { gameStats } from "@/game/stats";

type TouchInput = { forward: number; steer: number; brake: boolean };

export function HUD({ touch }: { touch: React.RefObject<TouchInput> }) {
  const [, force] = useState(0);

  useEffect(() => {
    const id = setInterval(() => force((n) => n + 1), 80);
    return () => clearInterval(id);
  }, []);

  const press = (patch: Partial<TouchInput>) => ({
    onPointerDown: (e: React.PointerEvent) => {
      e.preventDefault();
      Object.assign(touch.current, patch);
    },
    onPointerUp: () => Object.assign(touch.current, reset(patch)),
    onPointerLeave: () => Object.assign(touch.current, reset(patch)),
    onPointerCancel: () => Object.assign(touch.current, reset(patch)),
  });

  const reset = (patch: Partial<TouchInput>): Partial<TouchInput> => {
    const out: Partial<TouchInput> = {};
    if ("forward" in patch) out.forward = 0;
    if ("steer" in patch) out.steer = 0;
    if ("brake" in patch) out.brake = false;
    return out;
  };

  const btn =
    "pointer-events-auto select-none touch-none rounded-2xl bg-hud/80 px-5 py-4 text-lg font-bold text-hud-foreground shadow-lg backdrop-blur-sm active:scale-95 transition-transform";

  return (
    <div className="pointer-events-none fixed inset-0 z-10 font-sans">
      <div className="flex items-start justify-between p-4">
        <div className="rounded-2xl bg-hud/80 px-4 py-3 text-hud-foreground shadow-lg backdrop-blur-sm">
          <div className="text-xs uppercase tracking-widest opacity-70">
            Speed
          </div>
          <div className="text-3xl font-black tabular-nums leading-none">
            {Math.round(gameStats.speed)}
            <span className="ml-1 text-sm font-semibold opacity-70">km/h</span>
          </div>
        </div>
        <div className="rounded-2xl bg-hud/80 px-4 py-3 text-right text-hud-foreground shadow-lg backdrop-blur-sm">
          <div className="text-xs uppercase tracking-widest opacity-70">
            Rings
          </div>
          <div className="text-3xl font-black tabular-nums leading-none">
            {gameStats.coins}
            <span className="text-sm font-semibold opacity-70">
              /{gameStats.total}
            </span>
          </div>
          <div className="mt-1 text-xs font-semibold text-accent-foreground/80">
            Drift {Math.round(gameStats.driftScore)}
          </div>
        </div>
      </div>

      {gameStats.drifting && (
        <div className="animate-fade-in absolute left-1/2 top-24 -translate-x-1/2 rounded-full bg-drift px-5 py-2 text-sm font-black uppercase tracking-widest text-hud-foreground shadow-lg">
          Drifting!
        </div>
      )}

      <div className="absolute bottom-0 left-0 right-0 flex items-end justify-between p-5 md:hidden">
        <div className="flex gap-3">
          <button className={btn} {...press({ steer: 1 })} aria-label="Left">
            ◀
          </button>
          <button className={btn} {...press({ steer: -1 })} aria-label="Right">
            ▶
          </button>
        </div>
        <div className="flex gap-3">
          <button className={btn} {...press({ brake: true })} aria-label="Drift">
            ✦
          </button>
          <button
            className={btn}
            {...press({ forward: -1 })}
            aria-label="Reverse"
          >
            ▼
          </button>
          <button className={btn} {...press({ forward: 1 })} aria-label="Go">
            ▲
          </button>
        </div>
      </div>

      <div className="absolute bottom-5 left-1/2 hidden -translate-x-1/2 rounded-full bg-hud/70 px-4 py-2 text-xs font-semibold tracking-wide text-hud-foreground backdrop-blur-sm md:block">
        WASD / arrows to drive · Space to drift · collect the golden rings
      </div>
    </div>
  );
}
