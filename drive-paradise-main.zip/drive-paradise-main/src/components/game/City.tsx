import { Clone, useGLTF } from "@react-three/drei";
import { useMemo } from "react";
import {
  CELL,
  GRID,
  HALF_BLOCK,
  ROAD,
  WORLD_LIMIT,
  buildCity,
} from "@/game/world";

const MODEL_FILES = [
  "building-a",
  "building-c",
  "building-e",
  "building-h",
  "building-k",
  "building-n",
  "building-skyscraper-a",
  "building-skyscraper-c",
  "building-skyscraper-e",
];
MODEL_FILES.forEach((m) => useGLTF.preload(`/models/city/${m}.glb`));

function Tree({ x, z, scale }: { x: number; z: number; scale: number }) {
  return (
    <group position={[x, 0, z]} scale={scale}>
      <mesh position={[0, 0.9, 0]} castShadow>
        <cylinderGeometry args={[0.18, 0.24, 1.8, 6]} />
        <meshStandardMaterial color="#8a5a37" roughness={1} />
      </mesh>
      <mesh position={[0, 2.5, 0]} castShadow>
        <icosahedronGeometry args={[1.35, 0]} />
        <meshStandardMaterial color="#4f9d4a" roughness={0.9} flatShading />
      </mesh>
      <mesh position={[0.5, 1.9, 0.3]} castShadow>
        <icosahedronGeometry args={[0.8, 0]} />
        <meshStandardMaterial color="#5cb356" roughness={0.9} flatShading />
      </mesh>
    </group>
  );
}

function Buildings() {
  const blocks = useMemo(() => buildCity(), []);
  const models = MODEL_FILES.map((m) => useGLTF(`/models/city/${m}.glb`));
  const byName = useMemo(
    () => Object.fromEntries(MODEL_FILES.map((m, i) => [m, models[i]!.scene])),
    [models],
  );

  return (
    <group>
      {blocks.map((b, i) => (
        <group key={i}>
          {/* sidewalk pad */}
          <mesh position={[b.x, 0.08, b.z]} receiveShadow>
            <boxGeometry args={[HALF_BLOCK * 2, 0.16, HALF_BLOCK * 2]} />
            <meshStandardMaterial
              color={b.kind === "park" ? "#7fc26a" : "#cfc9bb"}
              roughness={1}
            />
          </mesh>
          {b.props.map((p, k) => (
            <Clone
              key={k}
              object={byName[p.model]!}
              position={[p.x, 0.16, p.z]}
              rotation={[0, p.rotation, 0]}
              scale={p.scale}
              castShadow
              receiveShadow
            />
          ))}
          {b.trees.map((t, k) => (
            <Tree key={k} x={t.x} z={t.z} scale={t.scale} />
          ))}
        </group>
      ))}
    </group>
  );
}

function Roads() {
  // Road centrelines sit between the blocks.
  const lines = useMemo(
    () =>
      Array.from(
        { length: GRID * 2 + 2 },
        (_, i) => (i - GRID - 0.5) * CELL,
      ),
    [],
  );
  const span = WORLD_LIMIT * 2;

  return (
    <group>
      {/* asphalt */}
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.02, 0]} receiveShadow>
        <planeGeometry args={[span, span]} />
        <meshStandardMaterial color="#5c5f66" roughness={0.95} />
      </mesh>
      {/* grass beyond the grid */}
      <mesh rotation-x={-Math.PI / 2} position={[0, -0.02, 0]} receiveShadow>
        <planeGeometry args={[span * 4, span * 4]} />
        <meshStandardMaterial color="#8ecb72" roughness={1} />
      </mesh>
      {/* centre lane dashes */}
      {lines.map((l) => (
        <group key={`x${l}`}>
          {Array.from({ length: 40 }, (_, i) => {
            const p = -WORLD_LIMIT + i * (span / 40) + 1;
            return (
              <group key={i}>
                <mesh rotation-x={-Math.PI / 2} position={[p, 0.04, l]}>
                  <planeGeometry args={[2.4, 0.35]} />
                  <meshStandardMaterial color="#f3e9c8" roughness={1} />
                </mesh>
                <mesh rotation-x={-Math.PI / 2} position={[l, 0.04, p]}>
                  <planeGeometry args={[0.35, 2.4]} />
                  <meshStandardMaterial color="#f3e9c8" roughness={1} />
                </mesh>
              </group>
            );
          })}
        </group>
      ))}
      {/* outer wall so the city has an edge */}
      {[-1, 1].map((s) => (
        <group key={s}>
          <mesh position={[s * (WORLD_LIMIT + ROAD / 2), 1, 0]} castShadow>
            <boxGeometry args={[2, 2, span + 4]} />
            <meshStandardMaterial color="#d8d2c4" roughness={1} />
          </mesh>
          <mesh position={[0, 1, s * (WORLD_LIMIT + ROAD / 2)]} castShadow>
            <boxGeometry args={[span + 4, 2, 2]} />
            <meshStandardMaterial color="#d8d2c4" roughness={1} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

export function City() {
  return (
    <group>
      <Roads />
      <Buildings />
    </group>
  );
}
