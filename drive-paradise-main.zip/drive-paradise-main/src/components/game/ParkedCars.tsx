import { Clone, useGLTF } from "@react-three/drei";
import { useMemo } from "react";
import { CELL, GRID, HALF_BLOCK } from "@/game/world";

const CARS = ["taxi", "police", "suv", "delivery"];
CARS.forEach((c) => useGLTF.preload(`/models/cars/${c}.glb`));

export function ParkedCars() {
  const models = CARS.map((c) => useGLTF(`/models/cars/${c}.glb`));

  const spots = useMemo(() => {
    const out: { model: number; x: number; z: number; rot: number }[] = [];
    let n = 0;
    for (let i = -GRID; i <= GRID; i++) {
      for (let j = -GRID; j <= GRID; j++) {
        if ((i + j + 7) % 3 !== 0) continue;
        const along = (((i * 7 + j * 3) % 5) - 2) * 4;
        out.push({
          model: Math.abs(i + j * 2) % CARS.length,
          x: i * CELL + HALF_BLOCK + 2.4,
          z: j * CELL + along,
          rot: 0,
        });
        out.push({
          model: Math.abs(i * 3 + j) % CARS.length,
          x: i * CELL + along,
          z: j * CELL - HALF_BLOCK - 2.4,
          rot: Math.PI / 2,
        });
        n++;
      }
    }
    return out.slice(0, 26 + n * 0);
  }, []);

  return (
    <group>
      {spots.map((s, i) => (
        <Clone
          key={i}
          object={models[s.model]!.scene}
          position={[s.x, 0, s.z]}
          rotation={[0, s.rot, 0]}
          scale={1.6}
          castShadow
        />
      ))}
    </group>
  );
}
