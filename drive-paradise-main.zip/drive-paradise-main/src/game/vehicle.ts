// Arcade vehicle model: tune the feel with these constants.
const ACCEL = 26;
const REVERSE = 14;
const BRAKE = 22;
const DRAG = 1.1;
const TURN = 2.4;
const GRIP = 6.5;
const DRIFT_GRIP = 1.4;
const MAX_SPEED = 42;

export interface VehicleState {
  px: number;
  pz: number;
  vx: number;
  vz: number;
  yaw: number;
  slip: number;
  speed: number;
}

export function createVehicle(px = 0, pz = 0): VehicleState {
  return { px, pz, vx: 0, vz: 0, yaw: 0, slip: 0, speed: 0 };
}

export function updateVehicle(
  s: VehicleState,
  input: { forward: number; steer: number; brake: boolean },
  dt: number,
) {
  const fdx = Math.sin(s.yaw);
  const fdz = Math.cos(s.yaw);
  const rdx = Math.cos(s.yaw);
  const rdz = -Math.sin(s.yaw);

  let vLong = s.vx * fdx + s.vz * fdz;
  let vLat = s.vx * rdx + s.vz * rdz;

  if (input.forward > 0) vLong += input.forward * ACCEL * dt;
  else if (input.forward < 0) vLong += input.forward * REVERSE * dt;
  if (input.brake) vLong -= Math.sign(vLong) * BRAKE * dt;
  vLong -= vLong * DRAG * dt;
  vLong = Math.max(-MAX_SPEED * 0.4, Math.min(MAX_SPEED, vLong));

  const speedFactor = Math.min(Math.abs(vLong) / 8, 1);
  const dir = vLong < 0 ? -1 : 1;
  s.yaw +=
    input.steer * TURN * speedFactor * dir * (input.brake ? 1.5 : 1) * dt;

  const grip = input.brake ? DRIFT_GRIP : GRIP;
  vLat *= Math.exp(-grip * dt);

  s.vx = fdx * vLong + rdx * vLat;
  s.vz = fdz * vLong + rdz * vLat;

  s.px += s.vx * dt;
  s.pz += s.vz * dt;

  s.speed = Math.sqrt(s.vx * s.vx + s.vz * s.vz);
  const va = Math.atan2(s.vx, s.vz);
  s.slip =
    s.speed > 0.4 ? Math.atan2(Math.sin(va - s.yaw), Math.cos(va - s.yaw)) : 0;
}
