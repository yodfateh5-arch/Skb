// Shared city layout constants and helpers (browser-safe, no three import).

export const CELL = 46; // distance between road centerlines
export const ROAD = 14; // road width
export const HALF_BLOCK = (CELL - ROAD) / 2; // half size of a city block
export const GRID = 3; // blocks reach from -GRID..GRID on each axis
export const WORLD_LIMIT = GRID * CELL + CELL / 2;

export type BlockKind = "buildings" | "park";

export interface CityBlock {
  x: number;
  z: number;
  kind: BlockKind;
  props: {
    model: string;
    x: number;
    z: number;
    rotation: number;
    scale: number;
  }[];
  trees: { x: number; z: number; scale: number }[];
}

const BUILDINGS = [
  "building-a",
  "building-c",
  "building-e",
  "building-h",
  "building-k",
  "building-n",
  "building-skyscraper-a",
  "building-skyscraper-c",
  "building-skyscraper-e",
];

// Deterministic pseudo-random so server and client agree.
function rand(seed: number) {
  const s = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
}

export function buildCity(): CityBlock[] {
  const blocks: CityBlock[] = [];
  let seed = 1;
  for (let i = -GRID; i <= GRID; i++) {
    for (let j = -GRID; j <= GRID; j++) {
      const cx = i * CELL;
      const cz = j * CELL;
      const r = rand(seed++);
      const kind: BlockKind = r > 0.82 ? "park" : "buildings";
      const props: CityBlock["props"] = [];
      const trees: CityBlock["trees"] = [];

      if (kind === "buildings") {
        for (let q = 0; q < 4; q++) {
          const ox = q % 2 === 0 ? -HALF_BLOCK / 2 : HALF_BLOCK / 2;
          const oz = q < 2 ? -HALF_BLOCK / 2 : HALF_BLOCK / 2;
          const pick = Math.floor(rand(seed++) * BUILDINGS.length);
          props.push({
            model: BUILDINGS[pick] ?? BUILDINGS[0]!,
            x: cx + ox,
            z: cz + oz,
            rotation: Math.floor(rand(seed++) * 4) * (Math.PI / 2),
            scale: 3.4 + rand(seed++) * 1.6,
          });
        }
      } else {
        for (let t = 0; t < 7; t++) {
          trees.push({
            x: cx + (rand(seed++) - 0.5) * (HALF_BLOCK * 1.6),
            z: cz + (rand(seed++) - 0.5) * (HALF_BLOCK * 1.6),
            scale: 0.8 + rand(seed++) * 0.6,
          });
        }
      }
      blocks.push({ x: cx, z: cz, kind, props, trees });
    }
  }
  return blocks;
}

/** Keep the car on the streets: push it out of any block it clips into. */
export function resolveCity(px: number, pz: number, radius: number) {
  const nx = Math.round(px / CELL) * CELL;
  const nz = Math.round(pz / CELL) * CELL;
  if (Math.abs(nx) > GRID * CELL + 1 || Math.abs(nz) > GRID * CELL + 1) {
    return { x: px, z: pz, hit: false };
  }
  const lx = px - nx;
  const lz = pz - nz;
  const limit = HALF_BLOCK + radius;
  if (Math.abs(lx) < limit && Math.abs(lz) < limit) {
    const penX = limit - Math.abs(lx);
    const penZ = limit - Math.abs(lz);
    if (penX < penZ) {
      return { x: nx + Math.sign(lx || 1) * limit, z: pz, hit: true };
    }
    return { x: px, z: nz + Math.sign(lz || 1) * limit, hit: true };
  }
  return { x: px, z: pz, hit: false };
}

export function buildCoins() {
  const coins: { x: number; z: number }[] = [];
  let seed = 500;
  for (let n = 0; n < 14; n++) {
    const onX = rand(seed++) > 0.5;
    const lane =
      (Math.floor(rand(seed++) * (GRID * 2 + 2)) - GRID - 0.5) * CELL;
    const along = (rand(seed++) - 0.5) * 2 * (GRID * CELL);
    coins.push(onX ? { x: lane, z: along } : { x: along, z: lane });
  }
  return coins;
}
