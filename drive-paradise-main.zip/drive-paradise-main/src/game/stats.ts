export const gameStats = {
  speed: 0,
  coins: 0,
  total: 0,
  drifting: false,
  driftScore: 0,
};
